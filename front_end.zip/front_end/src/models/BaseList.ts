export default class BaseList<T> {
	totalRecords!: number;
	results!: T;
}

