﻿using BookStore.Models.Models;
using Microsoft.AspNetCore.Mvc;
using BookStore.Repository;
using System.Linq;

namespace BookStore.Api.Controllers
{
    [ApiController]
    [Route("api/User/Roles")]
    public class RoleController : Controller
    {
        private readonly RoleRepository _roleRepository = new();
        [HttpGet]
        public IActionResult GetRoles()
        {
            var roles = _roleRepository.GetRoles();
            ListResponse<RoleModel> listResponse = new()
            {

                Results = roles.Results.Select(c => new RoleModel(c)),
                TotalRecords = roles.TotalRecords,
            };
            return Ok(listResponse);
        }
    }
}