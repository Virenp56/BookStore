﻿using System;

namespace BookStore.Repository
{
    public class Class1
    {
    }
}
